package Index;

import MotorVis.MvisualPrin;

public class ConvertNUmber {
    public static void main(String[] args) {
        MvisualPrin a = new MvisualPrin();
       
    }
    
}
